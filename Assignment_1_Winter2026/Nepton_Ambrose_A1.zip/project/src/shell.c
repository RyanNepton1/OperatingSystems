#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include <unistd.h>
#include "shell.h"
#include "interpreter.h"
#include "shellmemory.h"
#include <ctype.h>
int parseInput(char ui[]);

// Start of everything
int main(int argc, char *argv[]) {
    printf("Shell version 1.5 created Dec 2025\n");

    char prompt = '$';  				// Shell prompt
    char userInput[MAX_USER_INPUT];		// user's input stored here
    int errorCode = 0;					// zero means no error, default

    //init user input
    for (int i = 0; i < MAX_USER_INPUT; i++) {
        userInput[i] = '\0';
    }

    int isInteractive = isatty(fileno(stdin));
    
    //init shell memory
    mem_init();
    while(1) {							
        if (isInteractive) {
            printf("%c ", prompt);
        }
        // here you should check the unistd library 
        // so that you can find a way to not display $ in the batch mode
        if (fgets(userInput, MAX_USER_INPUT-1, stdin) == NULL) {
            break; // Exit on EOF
        }
        errorCode = parseInput(userInput);
        if (errorCode == -1) exit(99);	// ignore all other errors
        memset(userInput, 0, sizeof(userInput));
    }

    return 0;
}

int wordEnding(char c) {
    // You may want to add ';' to this at some point,
    // or you may want to find a different way to implement chains.
    return c == '\0' || c == '\n' || c == ' ' || c == ';';
}

int parseInput(char inp[]) {
    char tmp[200], *words[100];                            
    int ix = 0, w = 0;
    int wordlen;
    int TotalErrorS = 0;
    int errorCode;
    for (ix = 0; inp[ix] == ' ' && ix < 1000; ix++); // skip white spaces
    while (inp[ix] != '\n' && inp[ix] != '\0' && ix < 1000) {
        // extract a word
        for (wordlen = 0; !wordEnding(inp[ix]) && ix < 1000; ix++, wordlen++) {
            tmp[wordlen] = inp[ix];                        
        }
        tmp[wordlen] = '\0';
        if (wordlen > 0) {
            words[w] = strdup(tmp);
            w++;
        }
        // Check for chaining
        if (inp[ix] == ';') {
            if (w > 0) {
                errorCode = interpreter(words, w);
                TotalErrorS += errorCode;
            }
            // reset word count for next command
            w = 0; 
            // skip the semicolon
            ix++;   
            while (inp[ix] == ' ' && ix < 1000) ix++;
        }
        else if (inp[ix] == '\0') break;
        else ix++; 
    }
    // Run the last command
    errorCode = interpreter(words, w);
    // See if any errors != 0
    TotalErrorS += errorCode;
    return errorCode;
}

int isAlphanumeric(char inp[]) {
	for (int i = 0; inp[i] != '\0'; i++) {
        // Check if character is not alphanumeric
		if (!isalnum((unsigned char)inp[i])) {
			return 1;
		}
	}
	return 0;
}
